/*import { useFonts } from 'expo-font';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { AuthProvider } from '../src/context/AuthContext';

// This file is your "App.js" equivalent
export default function RootLayout() {
  // 1. Load Fonts (Optional, but good practice)
  const [loaded] = useFonts({
    // 'CustomFont': require('../assets/fonts/CustomFont.ttf'),
  });

  // 2. Wrap everything in Providers (Auth, Theme, etc)
  return (
    <AuthProvider>
      <StatusBar style="dark" />
      <Stack screenOptions={{ headerShown: false }}>
        {
      // Define your screens here if you want specific animations 
      }
        <Stack.Screen name="index" />
        <Stack.Screen name="login" />
        <Stack.Screen name="otp" />
        <Stack.Screen name="(tabs)" options={{ gestureEnabled: false }} />
      </Stack>
    </AuthProvider>
  );
}
*/
import { Stack } from 'expo-router';
import { AuthProvider } from '../contexts/AuthContext';
import '../global.css';

export default function RootLayout() {
  return (
    <AuthProvider>
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="(auth)" />
        <Stack.Screen name="(tabs)" />
        <Stack.Screen name="notifications" />
        <Stack.Screen name="profile" />
      </Stack>
    </AuthProvider>
  );
}
