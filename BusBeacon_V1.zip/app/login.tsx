import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import { Alert, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { PhoneInput, PrimaryButton } from '../src/components/AppComponents';

export default function LoginScreen() {
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleNext = async () => {
    if (phone.length < 10) {
      Alert.alert("Invalid Number", "Please enter a 10-digit number");
      return;
    }
    setLoading(true);
    // Simulate API Call
    await new Promise(r => setTimeout(r, 1000)); 
    setLoading(false);
    router.push({ pathname: '/otp', params: { phone } });
  };

  return (
    <SafeAreaView className="flex-1 bg-white">
      <View className="flex-1 p-6 justify-center">
        <Text className="text-3xl font-bold text-center mb-10">Sign in</Text>
        
        <PhoneInput value={phone} onChangeText={setPhone} />

        <View className="mt-5">
          <PrimaryButton 
            title="Next" 
            onPress={handleNext} 
            loading={loading} 
          />
        </View>
      </View>
    </SafeAreaView>
  );
}